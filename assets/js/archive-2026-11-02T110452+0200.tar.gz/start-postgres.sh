#!/bin/sh
# Вывести диагностику окружения и запустить существующий PostgreSQL.
# Скрипт не устанавливает пакеты и не изменяет конфигурацию или данные БД.
# Запускать через Startup вместо прежней команды postgres, не параллельно ей.

printf '\n=== SYSTEM ===\n'
uname -m
cat /etc/os-release
id

printf '\n=== AVAILABLE TOOLS ===\n'
for x in postgres pg_ctl node npm curl wget openssl; do
  command -v "$x" || :
done

printf '\n=== POSTGRES CONFIG ===\n'
postgres -D /home/container/postgres_db/ -C port
postgres -D /home/container/postgres_db/ -C listen_addresses

printf '\n=== START POSTGRES ===\n'
exec postgres -D /home/container/postgres_db/
