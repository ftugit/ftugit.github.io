#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ARCHIVE="$BASE/pg-proxy-kit.tar.xz"
EXPECTED=3bd758e184957ee588b4b867b20e4d720a050af84de2b62b3217f28297fcc168
DATA="$BASE/postgres_db"
fallback() {
  echo '=== Original PostgreSQL startup (proxy NOT enabled) ==='
  exec postgres -D "$DATA/"
}
[ -f "$DATA/PG_VERSION" ] || { echo 'ERROR: existing PostgreSQL data directory not found; no initdb will be run.' >&2; exit 1; }
if pg_ctl -D "$DATA" status >/dev/null 2>&1; then
  echo 'ERROR: server already running; use this script as Startup after a panel restart.' >&2
  exit 1
fi
if [ -e "$BASE/pg-proxy" ]; then
  if [ ! -f "$BASE/pg-proxy/KIT-VERSION" ] || [ "$(cat "$BASE/pg-proxy/KIT-VERSION")" != wispbyte-pgproxy-kit-1 ]; then
    echo 'ERROR: unknown existing pg-proxy directory; refusing to overwrite.' >&2
    fallback
  fi
  echo 'Existing kit found; not overwriting config or secrets.'
else
  for cmd in sha256sum; do
    if ! command -v "$cmd" >/dev/null 2>&1; then echo "ERROR: missing $cmd" >&2; fallback; fi
  done
  if [ ! -f "$ARCHIVE" ]; then echo 'ERROR: upload pg-proxy-kit.tar.xz next to this script.' >&2; fallback; fi
  ACTUAL=$(sha256sum "$ARCHIVE")
  ACTUAL=${ACTUAL%% *}
  if [ "$ACTUAL" != "$EXPECTED" ]; then echo 'ERROR: archive SHA-256 mismatch; refusing extraction.' >&2; fallback; fi
  for name in start-proxy.sh check-proxy.sh rollback-postgres.sh README-RU.md local-test-results.json tests client-example; do
    if [ -e "$BASE/$name" ]; then echo "ERROR: $name already exists; refusing overwrite." >&2; fallback; fi
  done
  echo '=== Verified archive; extracting portable runtime (installer v2) ==='
  if [ -x /bin/busybox ]; then
    echo 'Extractor: /bin/busybox tar (no external xz required)'
    if ! /bin/busybox tar -xJf "$ARCHIVE" -C "$BASE"; then
      echo 'ERROR: BusyBox extraction failed. No DB changes made.' >&2
      fallback
    fi
  elif command -v busybox >/dev/null 2>&1; then
    echo 'Extractor: busybox tar (no external xz required)'
    if ! busybox tar -xJf "$ARCHIVE" -C "$BASE"; then
      echo 'ERROR: BusyBox extraction failed. No DB changes made.' >&2
      fallback
    fi
  else
    echo 'ERROR: BusyBox not found. Refusing to use tar with unknown xz support.' >&2
    fallback
  fi
fi
if [ ! -f "$BASE/pg-proxy/config.json" ]; then
  (umask 077; cp "$BASE/pg-proxy/config.example.json" "$BASE/pg-proxy/config.json")
fi
echo 'Edit pg-proxy/config.json in the file manager; do not share its contents.'
echo 'To enable proxy AFTER successful check: sh /home/container/start-proxy.sh'
if [ ! -f "$BASE/check-proxy.sh" ]; then echo 'ERROR: incomplete kit; staying on original PostgreSQL.' >&2; fallback; fi
exec sh "$BASE/check-proxy.sh"
