#!/bin/sh
# Startup вместо start-proxy.sh, после штатной остановки сервера в панели.
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
exec postgres -D "$BASE/postgres_db/"
