#!/bin/sh
# Startup: sh /home/container/start-proxy.sh
# Ничего не устанавливает; не вызывает initdb и не меняет postgresql.conf.
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
KIT="$BASE/pg-proxy"
DATA="$BASE/postgres_db"
export KIT DATA
NODE="$KIT/run-node.sh"
[ -f "$DATA/PG_VERSION" ] || { echo 'ERROR: existing postgres_db/PG_VERSION not found; refusing initdb.' >&2; exit 1; }
[ "$(cat "$DATA/PG_VERSION")" = 16 ] || { echo 'ERROR: this kit was tested with PostgreSQL 16 only.' >&2; exit 1; }
for cmd in postgres pg_ctl; do command -v "$cmd" >/dev/null || { echo "ERROR: missing $cmd" >&2; exit 1; }; done
[ -f "$KIT/config.json" ] || { echo 'ERROR: copy pg-proxy/config.example.json to pg-proxy/config.json and edit it.' >&2; exit 1; }
if pg_ctl -D "$DATA" status >/dev/null 2>&1; then
  echo 'ERROR: PostgreSQL already running. Use this file as Startup, not from a second console.' >&2
  exit 1
fi
sh "$NODE" "$KIT/launcher.mjs" --prepare
PORT=$(postgres -D "$DATA" -C port)
case "$PORT" in ''|*[!0-9]*) echo 'ERROR: invalid PostgreSQL port' >&2; exit 1;; esac
export PROXY_PORT="$PORT" PG_SOCKET_PORT="$PORT" PG_SOCKET_DIR="$DATA/run"
mkdir -p "$PG_SOCKET_DIR"
pg_pid=''
proxy_pid=''
cleanup() {
  trap '' INT TERM HUP
  if [ -n "$proxy_pid" ]; then
    kill -TERM "$proxy_pid" 2>/dev/null || :
    n=0
    while kill -0 "$proxy_pid" 2>/dev/null && [ "$n" -lt 15 ]; do sleep 1; n=$((n+1)); done
    kill -KILL "$proxy_pid" 2>/dev/null || :
    wait "$proxy_pid" 2>/dev/null || :
  fi
  if [ -n "$pg_pid" ]; then
    # SIGINT = PostgreSQL fast shutdown, с откатом незавершённых транзакций.
    kill -INT "$pg_pid" 2>/dev/null || :
    wait "$pg_pid" 2>/dev/null || :
  fi
}
trap cleanup EXIT
trap 'exit 0' INT TERM HUP
printf '\n=== PostgreSQL: Unix socket only; original config untouched ===\n'
postgres -D "$DATA" -c listen_addresses= -c "unix_socket_directories=$PG_SOCKET_DIR" &
pg_pid=$!
n=0
while [ ! -S "$PG_SOCKET_DIR/.s.PGSQL.$PORT" ]; do
  if ! kill -0 "$pg_pid" 2>/dev/null; then echo 'ERROR: PostgreSQL exited.' >&2; exit 1; fi
  n=$((n+1))
  [ "$n" -le 90 ] || { echo 'ERROR: timed out waiting for PostgreSQL socket.' >&2; exit 1; }
  sleep 1
done
printf '\n=== HTTP/WS proxy on 0.0.0.0:%s ===\n' "$PORT"
sh "$NODE" "$KIT/launcher.mjs" &
proxy_pid=$!
while kill -0 "$pg_pid" 2>/dev/null && kill -0 "$proxy_pid" 2>/dev/null; do sleep 1; done
echo 'ERROR: one of the services exited; stopping its companion.' >&2
exit 1
