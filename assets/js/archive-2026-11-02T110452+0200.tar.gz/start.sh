#!/bin/sh
set -e
# Wispbyte working directory; load only your own trusted, shell-compatible .env.
cd /home/container
if [ -f /home/container/.env ]; then
  set -a; . /home/container/.env; set +a
fi
if [ -z "$LS_BUCKET" ]; then
  if [ -n "$R2_ACCOUNT_ID" ] && [ -n "$R2_BUCKET" ] \
    && [ -n "$R2_ACCESS_KEY_ID" ] && [ -n "$R2_SECRET_ACCESS_KEY" ]; then
    LS_BUCKET="$R2_BUCKET"
    LS_ENDPOINT="https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com"
    LS_ACCESS_KEY_ID="$R2_ACCESS_KEY_ID"
    LS_SECRET_ACCESS_KEY="$R2_SECRET_ACCESS_KEY"
  elif [ -n "$S3_ENDPOINT" ] && [ -n "$S3_BUCKET" ] \
    && [ -n "$S3_ACCESS_KEY_ID" ] && [ -n "$S3_SECRET_ACCESS_KEY" ]; then
    LS_BUCKET="$S3_BUCKET"
    LS_ENDPOINT="$S3_ENDPOINT"
    LS_ACCESS_KEY_ID="$S3_ACCESS_KEY_ID"
    LS_SECRET_ACCESS_KEY="$S3_SECRET_ACCESS_KEY"
  fi
fi
export LS_BUCKET LS_ENDPOINT LS_ACCESS_KEY_ID LS_SECRET_ACCESS_KEY
export LS_REGION="${LS_REGION:-${S3_REGION:-auto}}"

echo "start.sh: bucket=$LS_BUCKET endpoint=$LS_ENDPOINT region=$LS_REGION port=${SERVER_PORT:-8090}"
mkdir -p pb_data
if [ ! -x ./litestream ]; then
  echo "start.sh: extracting litestream"
  tar xzf litestream-0.5.17-linux-x86_64.tar.gz
fi
chmod +x ./pbseed ./litestream
cat > litestream.yml <<'YML'
# Реже обходим S3/B2 для очистки и объединения файлов реплики.
# Интервалы отправки изменений двух БД остаются 10s / 300s.
l0-retention-check-interval: 1h
levels:
  - interval: 15m
  - interval: 1h
  - interval: 6h

dbs:
  - path: /home/container/pb_data/data.db
    replica:
      type: s3
      bucket: ${LS_BUCKET}
      path: pbseed/data.db
      endpoint: ${LS_ENDPOINT}
      region: ${LS_REGION}
      access-key-id: ${LS_ACCESS_KEY_ID}
      secret-access-key: ${LS_SECRET_ACCESS_KEY}
      sync-interval: 10s
  - path: /home/container/pb_data/auxiliary.db
    replica:
      type: s3
      bucket: ${LS_BUCKET}
      path: pbseed/auxiliary.db
      endpoint: ${LS_ENDPOINT}
      region: ${LS_REGION}
      access-key-id: ${LS_ACCESS_KEY_ID}
      secret-access-key: ${LS_SECRET_ACCESS_KEY}
      sync-interval: 300s
YML
exec ./litestream replicate -restore-if-db-not-exists -config /home/container/litestream.yml -exec "./pbseed serve --http=0.0.0.0:${SERVER_PORT:-8090} --dir=./pb_data"
